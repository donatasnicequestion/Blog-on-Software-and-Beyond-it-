@javax.xml.bind.annotation.XmlSchema(
    namespace = "http://activity.services.model.sample.soa")
package soa.sample.model.services.activity;