@javax.xml.bind.annotation.XmlSchema(
    namespace = "http://processes.model.sample.soa")
package soa.sample.model.processes;