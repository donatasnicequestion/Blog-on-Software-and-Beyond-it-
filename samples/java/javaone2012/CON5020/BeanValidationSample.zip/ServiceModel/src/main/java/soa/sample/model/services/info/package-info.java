@javax.xml.bind.annotation.XmlSchema(
    namespace = "http://info.services.model.sample.soa")
package soa.sample.model.services.info;