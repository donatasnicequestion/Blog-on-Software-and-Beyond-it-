@javax.xml.bind.annotation.XmlSchema(
    namespace = "http://process.activity.claims.data.model.sample.soa",                
    elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED,
    attributeFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package soa.sample.model.data.claims.activity.process;