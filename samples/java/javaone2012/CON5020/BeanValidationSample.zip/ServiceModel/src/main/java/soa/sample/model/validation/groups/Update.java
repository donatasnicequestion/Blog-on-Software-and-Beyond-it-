package soa.sample.model.validation.groups;


/** JavaOne2012-CON5020-Using JSR 303 Bean Validation with the Common Data Model in SOA
 * 
 * Validation group for service operations updating existing object
 *
 * @author Donatas Valys
 */
public interface Update { }
