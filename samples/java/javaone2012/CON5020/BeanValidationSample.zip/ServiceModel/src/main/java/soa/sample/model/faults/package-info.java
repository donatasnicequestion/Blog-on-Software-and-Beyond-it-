@javax.xml.bind.annotation.XmlSchema(
namespace = "http://faults.model.sample.soa",                
    elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED,
    attributeFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package soa.sample.model.faults;
